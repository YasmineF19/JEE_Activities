package com.example.demo;

public interface IDao {
    String getDate();
}
