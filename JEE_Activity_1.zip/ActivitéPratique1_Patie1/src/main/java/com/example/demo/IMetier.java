package com.example.demo;

public interface IMetier {
    String calcul();
}
