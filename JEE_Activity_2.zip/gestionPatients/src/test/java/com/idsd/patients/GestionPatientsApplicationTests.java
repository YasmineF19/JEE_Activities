package com.idsd.patients;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.idsd.patients.entities.Patient;
import com.idsd.patients.repos.PatientRepository;

@SpringBootTest
class GestionPatientsApplicationTests {

    @Autowired
    private PatientRepository patientRepository;

    @Test
    public void testCreatePatient() {
        Patient prod = new Patient("Ahmed", new Date(), true, 75);
        Patient prod1 = new Patient("Ali", new Date(), false, 78);
        Patient prod2 = new Patient("Mriem", new Date(), true, 108);
        patientRepository.save(prod);
        patientRepository.save(prod1);
        patientRepository.save(prod2);
    }

    @Test
    public void testListPatients() {
        List<Patient> patients = patientRepository.findAll();
        for (Patient p : patients) {
            System.out.println(p.getNom());
        }
    }

    @Test
    public void testSearchPatientById() {
        // Hardcoded ID for demo purposes — make sure this ID exists
        Long id = 1L;
        patientRepository.findById(id).ifPresentOrElse(
            p -> System.out.println(p.getNom()),
            () -> System.out.println("Patient not found")
        );
    }

    @Test
    public void testSearchPatientsByName() {
        List<Patient> patients = patientRepository.chercherPatients("Ahmed");
        for (Patient p : patients) {
            System.out.println(p.getNom());
        }
    }
    
    @Test
    public void testUpdatePatient()
    {
    Patient p = patientRepository.findById(1L).get();
    p.setNom("Yasmine");
    patientRepository.save(p);
    }
    @Test
    public void testdeletepatient()
    {
 patientRepository.deleteById((long) 2);
  
    }
}
