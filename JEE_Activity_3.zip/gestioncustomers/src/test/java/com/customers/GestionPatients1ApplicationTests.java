package com.customers;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customers.repository.CustomerRepository;
import com.customers.service.entities.Customer;


@SpringBootTest

class GestionPatients1ApplicationTests {
	  @Autowired
	    private CustomerRepository customerRepository;	
	  @Test
	  public void testcreateCustomer() {
		  customerRepository.save(new Customer("amir","amir@gmail.com"));
		  customerRepository.save(new Customer("yasmine","yasmine@gmail.com"));
		  customerRepository.save(new Customer("ali","ali@gmail.com"));
	  }
	  
	  
	
}
